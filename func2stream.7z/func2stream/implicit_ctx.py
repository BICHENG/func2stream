"""
implicit_ctx.py (v2 - Annotation Driven)

基于注解的隐式 Context 实现

Author: BI CHENG
GitHub: https://github.com/BICHENG/func2stream
License: MPL2.0

设计目标：
    消除 AST Magic，使用纯 Python 类型注解声明数据流
    
    用户只需写：
        def to_gray(frame) -> "gray":
            return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    多输出：
        def analyze(frame) -> ("gray", "edges"):
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 50, 150)
            return gray, edges
    
    纯副作用（无注解）：
        def display(frame):
            cv2.imshow("win", frame)

核心规则：
    1. 参数 → get 键（从 ctx 读取）
       - 无注解: 参数名作为 get 键
       - 字符串注解: 注解值作为 get 键（重映射）
       - 类型注解: 参数名作为 get 键
    2. 返回注解 → ret 键（写入 ctx）
       - "key" → 单输出
       - ("k1", "k2") → 多输出
       - 无注解 → 纯副作用，不写入 ctx
    3. 非字符串返回注解（如 int, List[str]）→ 不包装，保持原函数
    
    参数重映射示例：
        def process(img: "frame", cfg: "config") -> "result":
            # img 从 ctx["frame"] 读取
            # cfg 从 ctx["config"] 读取
            return model(img, cfg)
"""

import inspect
import functools
from typing import List, Callable, Any, Optional

from .basicnconst import assertl, logger


def _should_wrap(func) -> bool:
    """
    判断函数是否应该被 auto_ctx 包装
    
    规则（显式优于隐式）：
        - 有字符串返回注解 → 包装（如 -> "result"）
        - 有字符串元组返回注解 → 包装（如 -> ("a", "b")）
        - 无返回注解 → **不包装**（辅助函数）
        - 类型注解 → 不包装（如 -> int, -> dict）
    
    注意：此规则确保只有显式声明输出键的函数才会被包装，
    避免辅助函数被意外包装导致调用方式改变。
    """
    try:
        sig = inspect.signature(func)
        ret_anno = sig.return_annotation
        
        # 只有字符串注解才包装
        if isinstance(ret_anno, str):
            return True
        if isinstance(ret_anno, tuple) and all(isinstance(k, str) for k in ret_anno):
            return True
        
        # 无注解或类型注解都不包装
        return False
    except (ValueError, TypeError):
        return False


def _parse_annotation(func) -> tuple:
    """
    解析函数注解，返回 (get_keys, ret_keys)
    
    参数注解规则：
        - 无注解: 参数名作为 get 键
        - 字符串注解: 注解值作为 get 键（重映射）
        - 类型注解: 参数名作为 get 键
    
    Returns:
        (get_keys, ret_keys): 数据流声明
        (None, None): 函数不应被包装
    """
    try:
        sig = inspect.signature(func)
    except (ValueError, TypeError):
        return None, None
    
    # === get 键：从参数提取（支持重映射） ===
    get_keys = []
    for name, param in sig.parameters.items():
        if name in ('self', 'cls'):
            continue
        anno = param.annotation
        if anno is inspect.Parameter.empty:
            get_keys.append(name)
        elif isinstance(anno, str):
            get_keys.append(anno)
        else:
            get_keys.append(name)
    
    # === ret 键：从返回注解提取 ===
    ret_anno = sig.return_annotation
    
    if ret_anno is inspect.Signature.empty:
        ret_keys = []
    elif isinstance(ret_anno, str):
        ret_keys = [ret_anno]
    elif isinstance(ret_anno, tuple):
        if all(isinstance(k, str) for k in ret_anno):
            ret_keys = list(ret_anno)
        else:
            return None, None
    else:
        return None, None
    
    return get_keys, ret_keys


def _build_ctx_wrapper(func, get_keys: List[str], ret_keys: List[str]):
    """
    构建预编译的 ctx 包装器
    
    性能优化：根据 get/ret 数量生成特化版本，避免运行时分支
    """
    n_get = len(get_keys)
    n_ret = len(ret_keys)
    
    # === 预编译 getter（带友好错误信息）===
    if n_get == 0:
        def call_fn(ctx):
            return func()
    elif n_get == 1:
        _key = get_keys[0]
        def call_fn(ctx):
            if _key not in ctx:
                raise KeyError(
                    f"函数 {func.__name__}() 需要参数 '{_key}'，但 ctx 中不存在该键。\n"
                    f"可用的键有: {list(ctx.keys())}\n"
                    f"提示: 检查上游函数是否正确输出了 '{_key}'"
                )
            return func(ctx[_key])
    else:
        def call_fn(ctx):
            missing = [k for k in get_keys if k not in ctx]
            if missing:
                raise KeyError(
                    f"函数 {func.__name__}() 缺少参数: {missing}\n"
                    f"可用的键有: {list(ctx.keys())}\n"
                    f"提示: 检查上游函数是否正确输出了这些键"
                )
            args = [ctx[k] for k in get_keys]
            return func(*args)
    
    # === 错误提示 ===
    _fn_name = func.__name__
    _err_msg = (
        f"管道函数 {_fn_name}() 期望接收 ctx dict，但收到了 {{actual_type}}。\n"
        f"禁止在管道函数内部直接调用另一个管道函数。\n"
        f"正确做法：将函数分离为 Pipeline 中的独立步骤。"
    )
    
    # === 预编译 wrapper ===
    if n_ret == 0:
        @functools.wraps(func)
        def wrapper(ctx):
            assert isinstance(ctx, dict), _err_msg.format(actual_type=type(ctx).__name__)
            call_fn(ctx)
            return ctx
    elif n_ret == 1:
        _ret_key = ret_keys[0]
        @functools.wraps(func)
        def wrapper(ctx):
            assert isinstance(ctx, dict), _err_msg.format(actual_type=type(ctx).__name__)
            ctx[_ret_key] = call_fn(ctx)
            return ctx
    else:
        @functools.wraps(func)
        def wrapper(ctx):
            assert isinstance(ctx, dict), _err_msg.format(actual_type=type(ctx).__name__)
            result = call_fn(ctx)
            if not isinstance(result, tuple):
                result = (result,)
            assert len(ret_keys) == len(result), (
                f"{_fn_name} 声明返回 {len(ret_keys)} 个值 {ret_keys}，"
                f"实际返回 {len(result)} 个"
            )
            for k, v in zip(ret_keys, result):
                ctx[k] = v
            return ctx
    
    wrapper.fn = func
    wrapper.get = get_keys
    wrapper.ret = ret_keys
    wrapper._auto_ctx = True
    
    return wrapper


def auto_ctx(func):
    """
    基于注解的数据流包装器
    
    规则：
        1. 参数名 → get 键
        2. 返回注解 → ret 键
           - "key" → 单输出
           - ("k1", "k2") → 多输出
           - 无注解 → 纯副作用
        3. 非字符串注解 → 不包装
    
    Example:
        @auto_ctx
        def to_gray(frame) -> "gray":
            return cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        
        @auto_ctx
        def analyze(frame) -> ("gray", "edges"):
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            edges = cv2.Canny(gray, 50, 150)
            return gray, edges
        
        @auto_ctx
        def display(frame):  # 无注解 = 纯副作用
            cv2.imshow("win", frame)
    """
    get_keys, ret_keys = _parse_annotation(func)
    
    if get_keys is None:
        return func
    
    return _build_ctx_wrapper(func, get_keys, ret_keys)


def auto_ctx_full(func):
    """auto_ctx 的别名（保持向后兼容）"""
    return auto_ctx(func)


class Ctx:
    """
    类型标记（可选），用于 IDE 提示
    
    未来可扩展为：
        def process(frame: Ctx["frame"]) -> Ctx["result"]:
            ...
    """
    def __class_getitem__(cls, key):
        return key
